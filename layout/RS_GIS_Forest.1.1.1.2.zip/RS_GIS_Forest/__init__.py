# -*- coding: utf-8 -*-
"""RS GIS Forest - QGIS plugin loader."""
import os
import sys
import traceback
import importlib.util
from importlib.machinery import SourcelessFileLoader

_DIR = os.path.dirname(os.path.abspath(__file__))
_NAME = "rs_gis_forest_core"
_CORE = None


def _load_core():
    global _CORE
    if _CORE is not None:
        return _CORE
    tag = "cp%d%d" % sys.version_info[:2]
    path = os.path.join(_DIR, "%s.%s.pyc" % (_NAME, tag))
    if not os.path.isfile(path):
        have = sorted(f.split(".")[1] for f in os.listdir(_DIR) if f.startswith(_NAME) and f.endswith(".pyc"))
        raise ImportError("RS GIS Forest chưa có bản cho Python %d.%d của QGIS này (có sẵn: %s)."
                          % (sys.version_info[0], sys.version_info[1], ", ".join(have)))
    loader = SourcelessFileLoader(_NAME, path)
    spec = importlib.util.spec_from_file_location(_NAME, path, loader=loader)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[_NAME] = mod
    try:
        loader.exec_module(mod)
    except BaseException:
        sys.modules.pop(_NAME, None)
        raise
    _CORE = mod
    return mod


class RSGISForestPlugin(object):
    def __init__(self, iface):
        self.iface = iface
        self.core = None

    def initGui(self):
        try:
            self.core = _load_core()
            self.core.setup_toolbar()
            try:
                self.core._rs_install_autolayout_legend_hook()
            except Exception:
                pass
        except Exception as e:
            traceback.print_exc()
            try:
                from qgis.PyQt.QtWidgets import QMessageBox
                QMessageBox.critical(self.iface.mainWindow(), "RS GIS Forest",
                                     "Không nạp được RS GIS Forest:\n%s\n\n%s" % (e, traceback.format_exc()))
            except Exception:
                pass

    def unload(self):
        global _CORE
        c = self.core
        if c is None:
            return
        for fn in ("_rs_digitize_cleanup", "_remove_existing_toolbar", "_remove_existing_menu"):
            try:
                getattr(c, fn)()
            except Exception:
                pass
        try:
            from qgis.core import QgsProject
            prj = QgsProject.instance()
            hook = getattr(prj, "_rs_al_legend_hook", None)
            if hook is not None:
                prj.readProject.disconnect(hook)
                prj._rs_al_legend_hook = None
        except Exception:
            pass
        # Gỡ hẳn module lõi -> lần nạp sau (cập nhật / Plugin Reloader) đọc .pyc MỚI
        self.core = None
        _CORE = None
        sys.modules.pop(_NAME, None)


def classFactory(iface):
    return RSGISForestPlugin(iface)
